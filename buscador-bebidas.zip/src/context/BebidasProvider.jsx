import { createContext, useState, useEffect } from 'react';
import axios from 'axios';

const BebidasContext = createContext();

const BebidasProvider = ({ children }) => {

  const [bebidas, setBebidas] = useState([]);
  const [modal, setModal] = useState(false);
  const [idbebida, setIdBebida] = useState(null);
  const [receta, setReceta] = useState({});
  const [cargando, setCargando] = useState(false);


  useEffect(() => {
    if (!idbebida) return;
    setCargando(true);
    const consultarReceta = async () => {
      const url = `https://www.thecocktaildb.com/api/json/v1/1/lookup.php?i=${idbebida}`;
      try {
        const { data } = await axios.get(url);
        setReceta(data.drinks[0]);
      } catch (error) {
        console.error(error);
      } finally {
        setCargando(false);
      
      }
    }
    consultarReceta();
  }, [idbebida]);

  const consultarBebidas = async busqueda => {

    const url = `https://www.thecocktaildb.com/api/json/v1/1/filter.php?i=${busqueda.nombre}&c=${busqueda.categoria}`;
  
    try {
      const { data } = await axios(url);
      setBebidas(data.drinks);
    } catch (error) {
      console.error(error);
    }
  }

  const handleModalClick = () => {
    setModal(!modal);

  }

  const handleClickBebidaId = id => {
    setIdBebida(id);
  }


  return (
    <BebidasContext.Provider 
      value={{
        bebidas,
        consultarBebidas,
        handleModalClick,
        modal,
        handleClickBebidaId,
        receta,
        cargando
      }}
    >
      {children}
    </BebidasContext.Provider>
  )
}

export { 
  BebidasProvider
}

export default BebidasContext;