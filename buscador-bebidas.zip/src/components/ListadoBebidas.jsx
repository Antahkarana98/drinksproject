import { Row } from "react-bootstrap"
import useBebidas from "../hooks/useBebidas"
import Bebida from "./Bebida"

const ListadoBebidas = () => {

  const { bebidas } = useBebidas();

  return (
    <>
      <h2 className="text-center font-bold">Listado de bebidas</h2>

      <Row className="mt-5">

        {bebidas.map (bebida => (
          <Bebida 
            key={bebida.idDrink}
            bebida={bebida}
          />
        ))  
        } 
      </Row>
    </>
  )
}

export default ListadoBebidas
